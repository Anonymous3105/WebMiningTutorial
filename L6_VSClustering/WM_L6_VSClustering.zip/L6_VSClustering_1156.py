import numpy as np
from pprint import pprint
import requests
from bs4 import BeautifulSoup
import re

def get_web_text(url):
	try:
		page = requests.get(url)
	except Exception as e:
		try:
			print("Failed to reached {}".format(url))
		except UnicodeEncodeError:
			print("Failed to reached and cant show the URL")
		return None

	soup = BeautifulSoup(page.text, 'html.parser')

	# Removing style blocks
	[tag.decompose() for tag in soup("style")]

	# Removing scripts
	[tag.decompose() for tag in soup("script")]

	text = re.sub('\n+', ' ', soup.get_text()).strip().lower()
	return text


def get_word_count(words, text):
	if type(words) == str:
		return text.count(words)
	elif type(words) == list:
		return sum([text.count(wordi) for wordi in words])

class VSCluster():
	def __init__(self, threshold):
		self.threshold = threshold
		self.doclist = {}
		self.wordmap = {}
		self.doclist = {}		
		self.clusters = []
		self.freq_matrix = []
		self.clusterlist = {}

	def get_text_data(self, docfile):
		with open(docfile) as fp:
			content = list(map(str.lower, fp.readlines()))

		for textline in content:
			docname, doctext = textline.split(" : ")
			self.doclist[docname] = doctext

		self.freq_matrix = [[0 for i in range(len(self.doclist.keys()))] for i in range(len(self.doclist.keys()))]
		self.clusterlist = {doc:[] for doc in self.doclist.keys()}

	def get_URL_data(self, docfile):
		with open(docfile) as fp:
			urls = list(map(str.strip, fp.readlines()))

		for url in urls:
			self.doclist[url] = get_web_text(url)

		self.freq_matrix = [[0 for i in range(len(self.doclist.keys()))] for i in range(len(self.doclist.keys()))]
		self.clusterlist = {doc:[] for doc in self.doclist.keys()}


	def get_word_freq(self):
		for doc in self.doclist:
			self.wordmap[doc] = np.array([get_word_count(word, self.doclist[doc]) for word in self.wordlist])
		


	def fit(self, wordlist, docfile, URL_Input=False):
		# self.wordlist = list(map(str.lower, wordlist))
		self.wordlist = wordlist

		if URL_Input == True:
			self.get_URL_data(docfile)
		else:
			self.get_text_data(docfile)
		
		self.get_word_freq()

		self.compute_difference()

	
	def compute_difference(self):
		for i, doci in enumerate(sorted(self.doclist.keys())):
			for j, docj in enumerate(sorted(self.doclist.keys())):
				self.freq_matrix[i][j] = round((sum((self.wordmap[doci] - self.wordmap[docj])**2))**(0.5), 4)
		# pprint(self.freq_matrix)

	def cluster(self):
		for i, doci in enumerate(sorted(self.doclist.keys())):
			for j, docj in enumerate(sorted(self.doclist.keys())):
				if i!=j and self.freq_matrix[i][j] < self.threshold and docj not in self.clusterlist[doci]:
					self.clusterlist[doci].append(docj)
		pprint(self.clusterlist)


	def print_details(self):
		pass


wordlist = ["automotive", "car", "motorcycle", "self-drive", "iot", "hire", "dhoni"]
docfile = "docfile.txt"

# vsobj = VSCluster(threshold=1.5)
# vsobj.fit(wordlist, docfile)
# vsobj.cluster()
# vsobj.print_details()

urlwordlist = ["tesla", "electric", ["car", "vehicle", "automobile"], "pollution", "de-monetisation" , "gst" , "black money"]
urldocfile = "urldocfile.txt"
vsobj2 = VSCluster(threshold=75)
vsobj2.fit(urlwordlist, urldocfile, True)
vsobj2.cluster()